// 条文详情弹窗 — 纯 JS 实现，不依赖 Alpine 可见性控制
(function () {
    'use strict';

    const OVERLAY_ID = 'clause-modal-overlay';
    const CONTENT_ID = 'clause-modal-content';
    const LOADING_CLASS = 'clause-modal-loading';

    let overlay = null;
    let loadingEl = null;
    let contentEl = null;

    function getEls() {
        overlay = document.getElementById(OVERLAY_ID);
        if (overlay) {
            loadingEl = overlay.querySelector('.' + LOADING_CLASS);
            contentEl = document.getElementById(CONTENT_ID);
        }
    }

    function show(id) {
        getEls();
        if (!overlay) return;

        overlay.style.display = 'flex';
        if (loadingEl) loadingEl.style.display = 'block';

        // 通过 HTMX 加载条文详情
        htmx.ajax('GET', '/clause/' + id, {
            target: '#' + CONTENT_ID,
            swap: 'innerHTML'
        });

        // 内容加载完成后隐藏加载状态
        if (contentEl) {
            contentEl.addEventListener('htmx:afterSettle', function onSettle() {
                if (loadingEl) loadingEl.style.display = 'none';
                contentEl.removeEventListener('htmx:afterSettle', onSettle);
            });
        }
    }

    function hide() {
        getEls();
        if (!overlay) return;
        overlay.style.display = 'none';
        if (loadingEl) loadingEl.style.display = 'none';
        if (contentEl) contentEl.innerHTML = '';
    }

    // 初始化：监听事件 + 键盘/点击关闭
    function init() {
        getEls();

        // 监听搜索结果点击
        window.addEventListener('view-clause', function (e) {
            show(e.detail.id);
        });

        if (!overlay) return;

        // ESC 关闭
        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape' && overlay.style.display === 'flex') {
                hide();
            }
        });

        // 点击遮罩关闭
        overlay.addEventListener('click', function (e) {
            if (e.target === overlay) hide();
        });
    }

    // 在 DOM 加载完成后初始化
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    // 导出 hide 以供 Alpine 组件（loading 指示器）调用
    window.closeClauseModal = hide;
})();
